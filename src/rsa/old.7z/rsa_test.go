package rsa

import (
    "fmt"
    "gitee.com/ddkwork/libraryGo/encoding/hex"
    "gitee.com/ddkwork/libraryGo/stream"
    "github.com/stretchr/testify/assert"
    "math/big"
    "math/rand"
    "testing"
    "time"
)

func TestRsa(t *testing.T) {
    r := New()
    src := stream.Default
    src.SetString("ddk")

    dst := r.Encrypt(src)
    assert.Equal(t, "a0716efd4c339d8000ed5db4ee52032ceac0cc036126cbf5d609dd19a083cbd9497f4426d7f9cf9481a6940cf0b02971c2fd21bf26a8efba222f15ab31b3ce129692ebfd0bdbebc680c328d1412ce8b443c1c7c3adbefeb4f301790fd966d6a58869970248dbdf79ed70f915be9095758f314ff2844c4f8f3c15fb40ec26edbe", dst.EncodeToHexString())

    println()
    println()
    println()

    d := r.Decrypt(dst)
    println(d.String()) //64646b
}

// Test the RSA implementation
func TestName(t *testing.T) {
    println("Test RSA crypto")
    rand.Seed(int64(time.Nanosecond)) // Initialise the random generator

    // Generate P and Q, two big prime numbers
    println("Generating primes...")
    p := create_random_prime(512)
    q := create_random_prime(512)
    fmt.Printf("Prime p:\r\n %x\r\n", p)
    fmt.Printf("Prime q:\r\n %x\r\n", q)

    // Make n (the public key) now: n=p*q
    n := new(big.Int).Mul(p, q)
    fmt.Printf("Public key (n):\r\n %x\r\n", n)

    // Public exponent (always 0x10001)
    e := big.NewInt(0x10001)
    fmt.Printf("Exponent (e):\r\n %x\r\n", e)

    // Create phi: (p-1)*(q-1)
    one := big.NewInt(1)
    p_minus_1 := new(big.Int).Sub(p, one)
    q_minus_1 := new(big.Int).Sub(q, one)
    phi := new(big.Int).Mul(p_minus_1, q_minus_1)

    // Create the private key - it is the modular multiplicative inverse of e mod phi
    d := new(big.Int).ModInverse(e, phi)
    fmt.Printf("Secret key (d):\r\n %x\r\n", d)

    // Create a message randomly
    m := create_random_bignum(512)

    hexStr := hex.EncodeToString([]byte("ddk"))
    newM, b := new(big.Int).SetString(hexStr, 16)
    if !b {
        return
    }
    m = newM
    fmt.Printf("Message (m):\r\n %x\r\n", m)

    // Encrypt it: c = m^e mod n
    c := new(big.Int).Exp(m, e, n)
    fmt.Printf("Encrypt Crypto-text (c):\r\n %x\r\n", c)

    // Decrypt it: m = c^d mod n
    a := new(big.Int).Exp(c, d, n)
    fmt.Printf("Decrypt Message (c):\r\n %x\r\n", a)
}