package rsa

import (
	"gitee.com/ddkwork/libraryGo/log"
	"gitee.com/ddkwork/libraryGo/stream"
	"math/big"
)

type (
	Interface interface {
		Encrypt(src stream.Interface) (dst stream.Interface)
		Decrypt(src stream.Interface) (dst stream.Interface)
	}
	object struct {
		c *big.Int
		d *big.Int
		e *big.Int
		n *big.Int
	}
)

var l = log.Default

func (o *object) init() {
	//*o = object{}                 //reset
	p := create_random_prime(512) //c440da3f63fa0e2b32f18d7b76e9b3d78b1303c3f09ea6a6ba92da461363c48f765f9ec7ed4308060b7c01ef7cd76fb126f4bc94976644880b458fc0fe9a7193
	l.Hex("p", p)
	q := create_random_prime(512) //fd76d3567f9e0fac965edde9cb7e77d046e6587c69cb9fe1872ade55fae5c76fd983ab80a4d1427b85ccbe8c8e33a5a2459cd6bcff45338e74607cc9dabb704f
	l.Hex("q", q)
	o.n = new(big.Int).Mul(p, q) //c24f2f9902871e462a4c6649ef405c2e4fd19fdb416ec2bbf50d8b6915ecc000fee3fce62dd6e9bfff44f30087bf5a933759a7a5f2592c5a3acf5b1d7530c3f16b9806a34a8526026d03e57901a49a3e2523ee8e960174fd488e647999470a75bdaa993d42a3727f61738b749bbaba7023e646234e6b3aea2d8babe547ba5c5d
	l.Hex(" o.n", o.n)
	o.e = big.NewInt(0x10001)
	l.Hex("o.e ", o.e) //10001
	// Create phi: (p-1)*(q-1)
	one := big.NewInt(1)
	p_minus_1 := new(big.Int).Sub(p, one)
	q_minus_1 := new(big.Int).Sub(q, one)
	phi := new(big.Int).Mul(p_minus_1, q_minus_1)
	o.d = new(big.Int).ModInverse(o.e, phi) //ab44ece96b86f9b252fa40770ec1a5fed4302b3d31719587e2b9eb95d6d37571eb39bde28da90f2442b6dd922c15089b168099faf5a0902d8004e1851794c23fef7666481fdef201d385112772baaba728eb2f4671d41208e8d6e9863f4aad3b6a0bf1965041feb803d294518006b1fc9bc3b652902a206a40af53447c656869
	l.Hex(" o.d", o.d)
}

func (o *object) Encrypt(src stream.Interface) (dst stream.Interface) {
	l.Hex("m", src.Bytes())
	o.init()
	m := new(big.Int).SetBytes(src.Bytes()) //64646b
	o.c = new(big.Int).Exp(m, o.e, o.n)     //a0716efd4c339d8000ed5db4ee52032ceac0cc036126cbf5d609dd19a083cbd9497f4426d7f9cf9481a6940cf0b02971c2fd21bf26a8efba222f15ab31b3ce129692ebfd0bdbebc680c328d1412ce8b443c1c7c3adbefeb4f301790fd966d6a58869970248dbdf79ed70f915be9095758f314ff2844c4f8f3c15fb40ec26edbe
	l.Hex("o.c", o.c)
	return stream.NewHexString(l.Msg())
}

func (o *object) Decrypt(src stream.Interface) (dst stream.Interface) {
	//o.init()
	c, b := new(big.Int).SetString(src.EncodeToHexString(), 16)
	if !b {
		return
	}
	o.c = c
	m := new(big.Int).Exp(o.c, o.d, o.n)
	l.Hex("m", m)
	return stream.NewHexString(l.Msg())
}

var Default = New()

func New() Interface { return &object{} }
